#include<bits/stdc++.h>
#include <iostream>
#include <fstream>
using namespace std;

//function to push all the biased data
vector<float> extract(vector<float> push)
{
    float value;
    //embed into MATLAB file to extract data from MATLAB
    ifstream MATLAB("DataBiasHealthCare.mlx");
    while (getline (MATLAB, value)) 
    {
        push.push_back(value);
    }
    MATLAB.close();
    return push;
}

//to show the values when user asks for the biased dataset
void show(vector<float> use)
{
    for(int i=0;i<use.size();i++)
    {
        cout<<use[i]<<endl;
    }
    cout<<endl<<"These data are miscellaneous!";
}

int main()
{
    //radius
    vector<float> rad_data;
    //perimeter
    vector<float> per_data;
    //area
    vector<float> are_data;
    //smoothness
    vector<float> smo_data;
    
    //dataset radius
    rad_data = extract(rad_data);
    //dataset perimeter
    per_data = extract(per_data);
    //dataset area
    are_data = extract(are_data);
    //dataset smoothness
    smo_data = extract(smo_data);
    
    string res;
    //if some data is being extracted, then the data set is not unbiased
    if(rad_data.size()!=0||per_data.size()!=0||are_data.size()!=0||smo_data.size()!=0)
    {
        cout<<"Data set is not unbiased"<<endl<<"Would you like to see which data(s) causing this problem ?(Y/N)";
        cin>>res;
        
        if(res=="N")
        {
            cout<<"You will be using a biased training data set!";
            exit(0);
        }
        
        //showing all the values if the value is pushed from MATLAB file
        else if(res=="Y")
        {
            if(rad_data.size()!=0)
                show(rad_data);
                
            if(per_data.size()!=0)
                show(per_data);
                
            if(are_data.size()!=0)
                show(are_data);
                
            if(smo_data.size()!=0)
                show(smo_data);
        }
        
        else
        {
            cout<<"Invalid Entry";
            exit(0);
        }
    }
}